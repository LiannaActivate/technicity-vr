using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelStateManager : MonoBehaviour
{
    public static bool isTriggerAlarm;

    // Start is called before the first frame update
    void Start()
    {
        isTriggerAlarm = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
